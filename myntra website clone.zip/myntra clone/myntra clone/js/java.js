function filterFunction() {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    div = document.getElementById("myDropdown");
    a = div.getElementsByTagName("a");
    for (i = 0; i < a.length; i++) {
      txtValue = a[i].textContent || a[i].innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        a[i].style.display = "";
      } else {
        a[i].style.display = "none";
      }
    }

}
  function mydisplay(){
    var a = document.getElementById("myInput").value;
    if(a != ''){
      document.getElementById("myDropdown").style.display = "none";
    }
    else{
      document.getElementById("myDropdown").style.display = "block";
  
    }
  }
  // function mydisplay1(){
  //   var a = document.getElementById("myInput").value;
  //   var b = document.getElementsByTagName("a");

  //   if(a == b){
  //     document.getElementById("myDropdown").style.display = "block";
  //   }
  //   else{
  //     document.getElementById("myDropdown").style.display = "none";
  
  //   }
  //   // document.getElementById("myDropdown").style.display = "none";
  // }
